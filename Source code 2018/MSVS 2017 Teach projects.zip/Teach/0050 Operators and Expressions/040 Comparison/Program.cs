﻿using System;

namespace _040_Comparison
{
    class Program
    {
        static void Main(string[] args)
        {
            int x = 10, y = 5;
            Console.WriteLine("x > y : " + (x > y)); // True 
            Console.WriteLine("x < y : " + (x < y)); // False 
            Console.WriteLine("x >= y : " + (x >= y)); // True 
            Console.WriteLine("x <= y : " + (x <= y)); // False 
            Console.WriteLine("x == y : " + (x == y)); // False 
            Console.WriteLine("x != y : " + (x != y)); // True
        }
    }
}