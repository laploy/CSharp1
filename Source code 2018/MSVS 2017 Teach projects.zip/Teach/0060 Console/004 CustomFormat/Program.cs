﻿using System;

namespace _004_CustomFormat
{
    class Program
    {
        static void Main(string[] args)
        {
            // CustomNumericFormats
            Console.WriteLine("{0:0.00}", 1);
            //Output: 1.00
            Console.WriteLine("{0:#.##}", 0.234);
            //Output: .23
            Console.WriteLine("{0:#####}", 12345.67);
            //Output: 12346
            Console.WriteLine("{0:(0#) ### ## ##}", 29342525);
            //Output: (02) 934 25 25
            Console.WriteLine("{0:%##}", 0.234);
            //Output: %23
            DateTime d = new DateTime(2012, 02, 27, 17, 30, 22);
            Console.WriteLine("{0:dd/MM/yyyy HH:mm:ss}", d);
            Console.WriteLine("{0:d.MM.yy}", d);
            Console.WriteLine("{0:G}", DayOfWeek.Wednesday); // Wednesday
            Console.WriteLine("{0:D}", DayOfWeek.Wednesday); // 3
            Console.WriteLine("{0:X}", DayOfWeek.Wednesday); // 00000003
        }
    }
}