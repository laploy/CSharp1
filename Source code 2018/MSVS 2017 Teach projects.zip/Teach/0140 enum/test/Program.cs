﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace test
{
    //Sat is 0, Sun is 1, Mon is 2
    enum Day { Sat, Sun, Mon, Tue, Wed, Thu, Fri };
    
    //Sat is 1, Sun is 2, Mon is 3
    enum Day2 : byte { Sat = 1, Sun, Mon, Tue, Wed, Thu, Fri };

    class Program
    {
        static void Main(string[] args)
        {
        }
    }
}


