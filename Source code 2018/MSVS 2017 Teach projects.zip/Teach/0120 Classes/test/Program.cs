﻿namespace test
{
    class foo
    {

    }
    class Program
    {
        static void Main(string[] args)
        {
            foo myFoo = new foo();
        }
    }
}

