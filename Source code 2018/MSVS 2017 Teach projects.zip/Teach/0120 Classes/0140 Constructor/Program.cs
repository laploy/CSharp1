﻿namespace _0140_Constructor
{
    class Foo
    {
        public Foo()
        {

        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            Foo myFoo = new Foo();

        }
    }
}
