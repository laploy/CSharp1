﻿using System;

namespace _006_Literals
{
    class Program
    {
        static void Main(string[] args)
        {
            // An ordinary character 
            char character = 'a';
            Console.WriteLine(character);
            // Unicode character code in a hexadecimal format 
            character = '\u003A';
            Console.WriteLine(character);
            // Assigning the single quotiation character (escaped as \') 
            character = '\'';
            Console.WriteLine(character);
            // Assigning the backslash character (escaped as \\) 
            character = '\\';
            Console.WriteLine(character);
            string quotation = "\"Hello, Jude\", he said.";
            Console.WriteLine(quotation);
            string path = "C:\\Windows\\Notepad.exe";
            Console.WriteLine(path);
            string verbatim = @"The \ is not escaped as \\. I am at a new line.";
            Console.WriteLine(verbatim);
            int myHex = 0x10;
            Console.WriteLine(myHex);
        }
    }
}