﻿using System;

namespace _002_FlotingPoint
{
    class Program
    {
        static void Main(string[] args)
        {
            float floatPI = 3.14f;
            Console.WriteLine(floatPI); // 3.14 
            double doublePI = 3.14;
            Console.WriteLine(doublePI); // 3.14 
            double nan = Double.NaN; Console.WriteLine(nan); // NaN 
            double infinity = Double.PositiveInfinity;
            Console.WriteLine(infinity); // Infinity
            // -------- Accuracy of Real types
            // Declare some variables 
            float floatPI2 = 3.141592653589793238f;
            double doublePI2 = 3.141592653589793238;
            // Print the results on the console 
            Console.WriteLine("Float PI2 is: " + floatPI2);
            Console.WriteLine("Double PI2 is: " + doublePI2);
            // Console output: // Float PI is: 3.141593 
            // Double PI is: 3.14159265358979

            Console.Read();
        }
    }
}