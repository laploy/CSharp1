﻿using System;

namespace _004_String
{
    class Program
    {
        static void Main(string[] args)
        {
            // Declare some variables 
            string firstName = "Loy";
            string lastName = "Vanich";
            string fullName = firstName + " " + lastName;
            // Print the results on the console 
            Console.WriteLine("Hello, " + firstName + "!");
            Console.WriteLine("Your full name is " + fullName + ".");
            // Console output: 
            // Hello, Loy! 
            // Your full name is Loy Vanich.
            Console.Read();
        }
    }
}