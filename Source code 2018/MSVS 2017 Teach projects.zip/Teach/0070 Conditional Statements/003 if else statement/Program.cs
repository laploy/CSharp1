﻿using System;

namespace _003_if_else_statement
{
    class Program
    {
        static void Main(string[] args)
        {
            // if else example
            int x = 2;
            if (x > 3)
            {
                Console.WriteLine("x is greater than 3");
            }
            else
            {
                Console.WriteLine("x is not greater than 3");
            }
            // x is not greater than 3

            // Nested "if" Statements – Example
            int first = 5;
            int second = 3;
            if (first == second)
            {
                Console.WriteLine("These two numbers are equal.");
            }
            else
            {
                if (first > second)
                {
                    Console.WriteLine("The first number is greater.");
                }
                else
                {
                    Console.WriteLine("The second number is greater.");
                }
            }
            // The first number is greater.
        }
    }
}