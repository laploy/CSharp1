﻿using System;

namespace test
{
    class Program
    {
        static void Main(string[] args)
        {
            int j = 0;
            int k = 100;
            Console.WriteLine("j = {0}  k = {1}", j, k);
            int x = k / j;
            Console.WriteLine("x = {0}", x);
        }
    }
}

