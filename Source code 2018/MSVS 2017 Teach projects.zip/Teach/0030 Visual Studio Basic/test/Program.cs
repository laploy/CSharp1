﻿using System;

namespace test
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write(@"begin
                /\
               /  \
              /    \
             /      \
            /        \
            ----------
            end");
            Console.ReadLine();
        }
    }
}