﻿using System;

namespace test
{
    class Program
    {
        static void Main(string[] args)
        {
            // Initialize the counter
            int counter = 0;
            // Execute the loop body while the loop condition holds
            while (counter <= 9)
            {
                // Print the counter value
                Console.WriteLine("Number : " + counter);
                // Increment the counter
                counter++;
            }
            // -----------------------------------
            // Summing the Numbers from 1 to N
            Console.Write("n = ");
            int n = int.Parse(Console.ReadLine());
            int num = 1;
            int sum = 1;
            Console.Write("The sum 1");
            while (num < n)
            {
                num++;
                sum += num;
                Console.Write(" + " + num);
            }
            Console.WriteLine(" = " + sum);
            // N = 3
            //The sum 1 + 2 + 3 = 6
            // -----------------------------------
            // Check if a Number is prime
            Console.Write("Enter a positive number: ");
            int num2 = int.Parse(Console.ReadLine());
            int divider = 2;
            int maxDivider = (int)Math.Sqrt(num2);
            bool prime = true;
            while (prime && (divider <= maxDivider))
            {
                if (num2 % divider == 0)
                {
                    prime = false;
                }
                divider++;
            }
            Console.WriteLine("Prime? " + prime);
            //Enter a positive number: 37
            //Prime? True
            //Enter a positive number: 34
            //Prime? False
        }
    }
}