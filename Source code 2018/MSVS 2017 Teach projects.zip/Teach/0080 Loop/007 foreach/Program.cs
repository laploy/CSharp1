﻿using System;

namespace _007_foreach
{
    class Program
    {
        static void Main(string[] args)
        {
            // int array items iteration
            int[] numbers = { 2, 3, 5, 7, 11, 13, 17, 19 };
            foreach (int i in numbers)
            {
                Console.Write(" " + i);
            }
            Console.WriteLine();
            // string array items iteration
            string[] towns = { "London", "Paris", "Milan", "New York" };
            foreach (string town in towns)
            {
                Console.Write(" " + town);
            }
            //2 3 5 7 11 13 17 19
            //London Paris Milan New York
        }
    }
}