﻿using System;

namespace _005_For_Loop
{
    class Program
    {
        static void Main(string[] args)
        {
            // Calculating N^M
            Console.Write("n = ");
            int n = int.Parse(Console.ReadLine());
            Console.Write("m = ");
            int m = int.Parse(Console.ReadLine());
            decimal result = 1;
            for (int i = 0; i < m; i++)
            {
                result *= n;
            }
            Console.WriteLine("n^m = " + result);
            //n = 2
            //m = 10
            //n ^ m = 1024
        }
    }
}