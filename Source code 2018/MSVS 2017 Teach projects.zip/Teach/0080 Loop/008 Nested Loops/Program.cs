﻿using System;

namespace _008_Nested_Loops
{
    class Program
    {
        static void Main(string[] args)
        {
            // Nested loop example
            // Printing a Triangle
            int n = int.Parse(Console.ReadLine());
            for (int row = 1; row <= n; row++)
            {
                for (int col = 1; col <= row; col++)
                {
                    Console.Write(col + " ");
                }
                Console.WriteLine();
            }
            //1
            //1 2
            //1 2 3
            //1 2 3 4
            //1 2 3 4 5
            //1 2 3 4 5 6
            //1 2 3 4 5 6 7
        }
    }
}