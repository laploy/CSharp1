﻿using System;
using System.Numerics;

namespace _003_Do_While_Loop
{
    class Program
    {
        static void Main(string[] args)
        {
            // do-while factorial using BigInteger
            // Add using System.Nuberics
            Console.Write("n = ");
            int n = int.Parse(Console.ReadLine());
            BigInteger factorial = 1;
            do
            {
                factorial *= n;
                n--;
            } while (n > 0);
            Console.WriteLine("n! = " + factorial);
        }
    }
}