﻿using System;

namespace _006_Continue
{
    class Program
    {
        static void Main(string[] args)
        {
            // calculate the sum of all odd integers 
            // in the range [1…n], which are not divisible by 7
            int n = int.Parse(Console.ReadLine());
            int sum = 0;
            for (int i = 1; i <= n; i += 2)
            {
                if (i % 7 == 0)
                {
                    continue;
                }
                sum += i;
            }
            Console.WriteLine("sum = " + sum);
        }
    }
}