﻿using System;

namespace _004_Do_while_example_2
{
    class Program
    {
        static void Main(string[] args)
        {
            // do-while example
            // Product in the Range [N…M]
            Console.Write("n = ");
            int n = int.Parse(Console.ReadLine());
            Console.Write("m = ");
            int m = int.Parse(Console.ReadLine());
            int num = n;
            long product = 1;
            do
            {
                product *= num;
                num++;
            } while (num <= m);
            Console.WriteLine("product[n...m] = " + product);
            //n = 2
            //m = 6
            //product[n...m] = 720
        }
    }
}