﻿using System;

namespace _0110_Variable_Scope
{
    class test
    {
        int a = 123;
        int b = 456;
        
        public test()
        {
            int a = 789;
            int b = 1122;

            Console.WriteLine(a);
            Console.WriteLine(this.a);
            Console.WriteLine(b);
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            test myTest = new test();
        }
    }
}
