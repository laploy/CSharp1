﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Media;

namespace Piano
{
    class Key
    {
        private string name;
        private string note;

        public string Name { get => name; set => name = value; }
        public string Note { get => note; set => note = value; }

        public Key()
        {
            name = "C";
            note = "f:\\temp\\01C4.wav";
        }
        public void Play()
        {
            SoundPlayer player = new SoundPlayer(note);
            player.PlaySync();
        }
    }
}
