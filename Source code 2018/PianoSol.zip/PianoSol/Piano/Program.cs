﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Piano
{
    class Program
    {
        static void Main(string[] args)
        {
            Piano myPiano = new Piano();
            string[] mySong = {"C", "A", "F" };
            myPiano.PlaySong(mySong);
        }
    }
}
