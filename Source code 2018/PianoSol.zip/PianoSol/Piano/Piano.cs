﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Piano
{
    class Piano
    {
        Key[] pianoKey;
        public Piano()
        {
            string path = "f:\\temp\\wav\\";
            int i = 0;
            pianoKey = new Key[13];

            for(int j = 0; j <= pianoKey.Length-1; j++)
            {
                Key k = new Key();
                pianoKey[j] = k;
            }
            
            pianoKey[i].Name = "C";
            pianoKey[i++].Note = path + "01c4.wav";

            pianoKey[i].Name = "Db";
            pianoKey[i++].Note = path + "02Db4.wav";

            pianoKey[i].Name = "D";
            pianoKey[i++].Note = path + "03D4.wav";

            pianoKey[i].Name = "Eb";
            pianoKey[i++].Note = path + "04Eb4.wav";

            pianoKey[i].Name = "E";
            pianoKey[i++].Note = path + "05E4.wav";

            pianoKey[i].Name = "F";
            pianoKey[i++].Note = path + "06F4.wav";

            pianoKey[i].Name = "Gb";
            pianoKey[i++].Note = path + "07Gb4.wav";

            pianoKey[i].Name = "G";
            pianoKey[i++].Note = path + "08G44.wav";

            pianoKey[i].Name = "Ab";
            pianoKey[i++].Note = path + "09Ab4.wav";

            pianoKey[i].Name = "A";
            pianoKey[i++].Note = path + "10A4.wav";

            pianoKey[i].Name = "Bb";
            pianoKey[i++].Note = path + "11Bd4.wav";

            pianoKey[i].Name = "B";
            pianoKey[i++].Note = path + "12B4.wav";

            pianoKey[i].Name = "C5";
            pianoKey[i++].Note = path + "13C5.wav";
        }
        public void PlaySong(string[] song)
        {
            foreach(string s in song)
            {
                for(int i = 0; i <= pianoKey.Length; i++)
                {
                    if(s == pianoKey[i].Name)
                    {
                        pianoKey[i].Play();
                        break;
                    }
                }
            }
        }
    }
}
