﻿namespace _005_Piano
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.buttonC4 = new System.Windows.Forms.Button();
            this.buttonDb = new System.Windows.Forms.Button();
            this.buttonD = new System.Windows.Forms.Button();
            this.buttonE = new System.Windows.Forms.Button();
            this.buttonF = new System.Windows.Forms.Button();
            this.buttonG = new System.Windows.Forms.Button();
            this.buttonA = new System.Windows.Forms.Button();
            this.buttonC5 = new System.Windows.Forms.Button();
            this.buttonB = new System.Windows.Forms.Button();
            this.buttonEb = new System.Windows.Forms.Button();
            this.buttonAb = new System.Windows.Forms.Button();
            this.buttonGb = new System.Windows.Forms.Button();
            this.buttonBb = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // buttonC4
            // 
            this.buttonC4.FlatAppearance.BorderSize = 4;
            this.buttonC4.Font = new System.Drawing.Font("Arial Black", 22.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonC4.Location = new System.Drawing.Point(58, 52);
            this.buttonC4.Name = "buttonC4";
            this.buttonC4.Size = new System.Drawing.Size(75, 230);
            this.buttonC4.TabIndex = 0;
            this.buttonC4.Text = "C";
            this.buttonC4.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.buttonC4.UseVisualStyleBackColor = true;
            this.buttonC4.Click += new System.EventHandler(this.buttonC4_Click);
            // 
            // buttonDb
            // 
            this.buttonDb.BackColor = System.Drawing.Color.Black;
            this.buttonDb.Font = new System.Drawing.Font("Arial Black", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonDb.ForeColor = System.Drawing.Color.Transparent;
            this.buttonDb.Location = new System.Drawing.Point(106, 49);
            this.buttonDb.Name = "buttonDb";
            this.buttonDb.Size = new System.Drawing.Size(61, 152);
            this.buttonDb.TabIndex = 1;
            this.buttonDb.Text = "Db";
            this.buttonDb.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.buttonDb.UseVisualStyleBackColor = false;
            this.buttonDb.Click += new System.EventHandler(this.buttonDb_Click);
            // 
            // buttonD
            // 
            this.buttonD.FlatAppearance.BorderSize = 4;
            this.buttonD.Font = new System.Drawing.Font("Arial Black", 22.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonD.Location = new System.Drawing.Point(139, 52);
            this.buttonD.Name = "buttonD";
            this.buttonD.Size = new System.Drawing.Size(75, 230);
            this.buttonD.TabIndex = 2;
            this.buttonD.Text = "D";
            this.buttonD.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.buttonD.UseVisualStyleBackColor = true;
            this.buttonD.Click += new System.EventHandler(this.buttonD_Click);
            // 
            // buttonE
            // 
            this.buttonE.FlatAppearance.BorderSize = 4;
            this.buttonE.Font = new System.Drawing.Font("Arial Black", 22.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonE.Location = new System.Drawing.Point(220, 52);
            this.buttonE.Name = "buttonE";
            this.buttonE.Size = new System.Drawing.Size(75, 230);
            this.buttonE.TabIndex = 3;
            this.buttonE.Text = "E";
            this.buttonE.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.buttonE.UseVisualStyleBackColor = true;
            this.buttonE.Click += new System.EventHandler(this.buttonE_Click);
            // 
            // buttonF
            // 
            this.buttonF.FlatAppearance.BorderSize = 4;
            this.buttonF.Font = new System.Drawing.Font("Arial Black", 22.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonF.Location = new System.Drawing.Point(301, 52);
            this.buttonF.Name = "buttonF";
            this.buttonF.Size = new System.Drawing.Size(75, 230);
            this.buttonF.TabIndex = 4;
            this.buttonF.Text = "F";
            this.buttonF.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.buttonF.UseVisualStyleBackColor = true;
            this.buttonF.Click += new System.EventHandler(this.buttonF_Click);
            // 
            // buttonG
            // 
            this.buttonG.FlatAppearance.BorderSize = 4;
            this.buttonG.Font = new System.Drawing.Font("Arial Black", 22.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonG.Location = new System.Drawing.Point(382, 52);
            this.buttonG.Name = "buttonG";
            this.buttonG.Size = new System.Drawing.Size(75, 230);
            this.buttonG.TabIndex = 5;
            this.buttonG.Text = "G";
            this.buttonG.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.buttonG.UseVisualStyleBackColor = true;
            this.buttonG.Click += new System.EventHandler(this.buttonG_Click);
            // 
            // buttonA
            // 
            this.buttonA.FlatAppearance.BorderSize = 4;
            this.buttonA.Font = new System.Drawing.Font("Arial Black", 22.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonA.Location = new System.Drawing.Point(463, 52);
            this.buttonA.Name = "buttonA";
            this.buttonA.Size = new System.Drawing.Size(75, 230);
            this.buttonA.TabIndex = 6;
            this.buttonA.Text = "A";
            this.buttonA.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.buttonA.UseVisualStyleBackColor = true;
            this.buttonA.Click += new System.EventHandler(this.buttonA_Click);
            // 
            // buttonC5
            // 
            this.buttonC5.FlatAppearance.BorderSize = 4;
            this.buttonC5.Font = new System.Drawing.Font("Arial Black", 22.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonC5.Location = new System.Drawing.Point(625, 52);
            this.buttonC5.Name = "buttonC5";
            this.buttonC5.Size = new System.Drawing.Size(75, 230);
            this.buttonC5.TabIndex = 8;
            this.buttonC5.Text = "C";
            this.buttonC5.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.buttonC5.UseVisualStyleBackColor = true;
            this.buttonC5.Click += new System.EventHandler(this.buttonC5_Click);
            // 
            // buttonB
            // 
            this.buttonB.FlatAppearance.BorderSize = 4;
            this.buttonB.Font = new System.Drawing.Font("Arial Black", 22.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonB.Location = new System.Drawing.Point(544, 52);
            this.buttonB.Name = "buttonB";
            this.buttonB.Size = new System.Drawing.Size(75, 230);
            this.buttonB.TabIndex = 7;
            this.buttonB.Text = "B";
            this.buttonB.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.buttonB.UseVisualStyleBackColor = true;
            this.buttonB.Click += new System.EventHandler(this.buttonB_Click);
            // 
            // buttonEb
            // 
            this.buttonEb.BackColor = System.Drawing.Color.Black;
            this.buttonEb.Font = new System.Drawing.Font("Arial Black", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonEb.ForeColor = System.Drawing.Color.Transparent;
            this.buttonEb.Location = new System.Drawing.Point(186, 49);
            this.buttonEb.Name = "buttonEb";
            this.buttonEb.Size = new System.Drawing.Size(61, 152);
            this.buttonEb.TabIndex = 11;
            this.buttonEb.Text = "Eb";
            this.buttonEb.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.buttonEb.UseVisualStyleBackColor = false;
            this.buttonEb.Click += new System.EventHandler(this.buttonEb_Click);
            // 
            // buttonAb
            // 
            this.buttonAb.BackColor = System.Drawing.Color.Black;
            this.buttonAb.Font = new System.Drawing.Font("Arial Black", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonAb.ForeColor = System.Drawing.Color.Transparent;
            this.buttonAb.Location = new System.Drawing.Point(431, 48);
            this.buttonAb.Name = "buttonAb";
            this.buttonAb.Size = new System.Drawing.Size(61, 152);
            this.buttonAb.TabIndex = 13;
            this.buttonAb.Text = "Ab";
            this.buttonAb.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.buttonAb.UseVisualStyleBackColor = false;
            this.buttonAb.Click += new System.EventHandler(this.buttonAb_Click);
            // 
            // buttonGb
            // 
            this.buttonGb.BackColor = System.Drawing.Color.Black;
            this.buttonGb.Font = new System.Drawing.Font("Arial Black", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonGb.ForeColor = System.Drawing.Color.Transparent;
            this.buttonGb.Location = new System.Drawing.Point(348, 48);
            this.buttonGb.Name = "buttonGb";
            this.buttonGb.Size = new System.Drawing.Size(61, 152);
            this.buttonGb.TabIndex = 12;
            this.buttonGb.Text = "Gb";
            this.buttonGb.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.buttonGb.UseVisualStyleBackColor = false;
            this.buttonGb.Click += new System.EventHandler(this.buttonGb_Click);
            // 
            // buttonBb
            // 
            this.buttonBb.BackColor = System.Drawing.Color.Black;
            this.buttonBb.Font = new System.Drawing.Font("Arial Black", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonBb.ForeColor = System.Drawing.Color.Transparent;
            this.buttonBb.Location = new System.Drawing.Point(509, 48);
            this.buttonBb.Name = "buttonBb";
            this.buttonBb.Size = new System.Drawing.Size(61, 152);
            this.buttonBb.TabIndex = 14;
            this.buttonBb.Text = "Bb";
            this.buttonBb.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.buttonBb.UseVisualStyleBackColor = false;
            this.buttonBb.Click += new System.EventHandler(this.buttonBb_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.LightSlateGray;
            this.ClientSize = new System.Drawing.Size(771, 319);
            this.Controls.Add(this.buttonBb);
            this.Controls.Add(this.buttonAb);
            this.Controls.Add(this.buttonGb);
            this.Controls.Add(this.buttonEb);
            this.Controls.Add(this.buttonC5);
            this.Controls.Add(this.buttonB);
            this.Controls.Add(this.buttonA);
            this.Controls.Add(this.buttonG);
            this.Controls.Add(this.buttonF);
            this.Controls.Add(this.buttonE);
            this.Controls.Add(this.buttonDb);
            this.Controls.Add(this.buttonC4);
            this.Controls.Add(this.buttonD);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button buttonC4;
        private System.Windows.Forms.Button buttonDb;
        private System.Windows.Forms.Button buttonD;
        private System.Windows.Forms.Button buttonE;
        private System.Windows.Forms.Button buttonF;
        private System.Windows.Forms.Button buttonG;
        private System.Windows.Forms.Button buttonA;
        private System.Windows.Forms.Button buttonC5;
        private System.Windows.Forms.Button buttonB;
        private System.Windows.Forms.Button buttonEb;
        private System.Windows.Forms.Button buttonAb;
        private System.Windows.Forms.Button buttonGb;
        private System.Windows.Forms.Button buttonBb;
    }
}

